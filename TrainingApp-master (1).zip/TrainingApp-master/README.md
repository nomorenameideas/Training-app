# Filter It
A filtering efficiency training application.

(c) Charles University, Faculty of Arts

The Filter It application was created with the support of Faculty of Arts of Charles University, project GA UK No. 899018 (Training of visual selective attention in older adults).
