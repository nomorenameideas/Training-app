package cz.nudz.www.trainingapp.enums;

/**
 * Created by artem on 09-Jul-17.
 */

public enum Side {
    RIGHT,
    LEFT
}
