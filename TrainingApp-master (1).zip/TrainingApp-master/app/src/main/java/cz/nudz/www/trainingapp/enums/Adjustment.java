package cz.nudz.www.trainingapp.enums;

/**
 * Created by artem on 15-Sep-17.
 */
public enum Adjustment {
    LOWERED,
    SAME,
    RAISED
}
